# v34 reproducibility pack (audit harness)

This directory contains small, deterministic scripts and JSON files referenced by `manuscript_v34.tex`.

## What this pack is
- An **audit harness** that evaluates the tail inequality at the low anchor `m=10, α=1`
  for a pinned choice of parameters and constant ledger.
- An explicit **exponent tracker**: the UE exponent `p` is recorded in both the constants file and
  the generated tail-check JSON to prevent silent exponent drift across versions.

## What this pack is NOT
- It does **not** certify the analytic constant ledger (`C_up, C1, C2, C_h''`).
- It does **not** prove the tail criterion uniformly in `m`, nor does it claim RH.
- It does **not** compute zeta zeros; the front-end certificate is a logic wrapper around an external result.

## Expected behavior in v34
In v34, the pointwise upper-envelope derivation supports UE exponent `p=1`.
Under the current collar/local-window mechanism, the tail inequality at `m=10` is therefore expected to
**fail** for typical constant ledgers (the local term is `δ`-inert). The harness records this outcome
honestly (`"pass": false`) and still verifies reproducibly.

## How to run
From this directory:

```bash
python3 v34_generate_tail_check.py v34_constants_m10.json v34_tail_check_m10.json
python3 v34_verify_tail_check.py --constants v34_constants_m10.json --certificate v34_tail_check_m10.json

python3 v34_verify_frontend_certificate.py --certificate v34_frontend_certificate.json
```

## Files
- `v34_constants_m10.json`: constants + parameters for the low-anchor tail evaluation (includes `UE_exponent_p`)
- `v34_generate_tail_check.py`: deterministic interval generator (directed-rounding intervals)
- `v34_tail_check_m10.json`: pinned generated tail-check payload (may report `"pass": false`)
- `v34_verify_tail_check.py`: verifier (regen + equality check; reports whether strict inequality holds)
- `v34_tail_check_verifier_output_m10.txt`: verifier console output
- `v34_frontend_certificate.json`: pinned finite-height assumption statement
- `v34_verify_frontend_certificate.py`: logic-only verifier
- `SHA256SUMS.txt`: SHA-256 hashes of the pack files (integrity check)
