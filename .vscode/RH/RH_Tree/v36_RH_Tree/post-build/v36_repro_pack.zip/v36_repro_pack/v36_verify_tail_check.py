#!/usr/bin/env python3
"""
v36_verify_tail_check.py

Verifier for v36_tail_check_m10.json. This script:
- loads the constants JSON and the pinned certificate JSON
- regenerates the certificate from constants
- checks exact JSON equality on the computed fields
- reports PASS/FAIL and prints the strict-separation check LHS_hi < RHS_lo.

Usage:
  python3 v36_verify_tail_check.py --constants v36_constants_m10.json --certificate v36_tail_check_m10.json

Exit codes:
- 0 on PASS
- nonzero on FAIL
"""

from __future__ import annotations

import argparse
import json
import sys

from v36_generate_tail_check import compute


def main() -> int:
    ap = argparse.ArgumentParser(description="Verify v36 tail check (m=10).")
    ap.add_argument("--constants", required=True, help="Path to v36_constants_m10.json")
    ap.add_argument("--certificate", required=True, help="Path to v36_tail_check_m10.json")
    args = ap.parse_args()

    with open(args.constants, "r", encoding="utf-8") as f:
        constants = json.load(f)

    with open(args.certificate, "r", encoding="utf-8") as f:
        cert = json.load(f)

    # ---- fail-closed metadata latch (v36) ----
    REQUIRED_META = [
        "UE_exponent_p",
        "UE_endpoint_class",
        "endpoint_functional",
        "forcing_architecture",
        "forceability_mode",
        "local_exponent_theta",
        "local_growth_q",
    ]
    for k in REQUIRED_META:
        if k not in constants or constants[k] in (None, ""):
            raise KeyError(f"Missing required metadata field {k!r} in constants (fail-closed).")
        if k not in cert or cert[k] in (None, ""):
            raise KeyError(f"Missing required metadata field {k!r} in certificate (fail-closed).")

    regen = {
        "certificate_version": "v36",
        "m_band": constants["m_band"],
        "eta": constants["eta"],
        "alpha": constants["alpha_worst"],
        "kappa": constants["kappa"],
        # required metadata latch (fail-closed)
        "UE_exponent_p": constants["UE_exponent_p"],
        "UE_endpoint_class": constants["UE_endpoint_class"],
        "endpoint_functional": constants["endpoint_functional"],
        "forcing_architecture": constants["forcing_architecture"],
        "forceability_mode": constants["forceability_mode"],
        "local_exponent_theta": constants["local_exponent_theta"],
        "local_growth_q": constants["local_growth_q"],
        "forcing_constants": constants.get("forcing_constants", {}),
        "manuscript_version": constants.get("manuscript_version", "v36"),
    }

    regen.update(compute(constants, prec=90))

    # Compare all keys that regen produces (ignore any extra keys in cert)
    ok = True
    for k, v in regen.items():
        if cert.get(k) != v:
            ok = False
            print(f"MISMATCH key={k}")
            print("  cert :", cert.get(k))
            print("  regen:", v)

    lhs_hi = regen["lhs_interval"]["hi"]
    rhs_lo = regen["rhs_interval"]["lo"]
    strict = (float(lhs_hi) < float(rhs_lo))

    print("LHS_hi =", lhs_hi)
    print("RHS_lo =", rhs_lo)
    print("STRICT (LHS_hi < RHS_lo) =", strict)

    print("REGEN_MATCH =", ok)
    print("INEQUALITY_STRICT =", strict)
    print("CERT_REPORTED_PASS =", regen.get("pass"))

    if not ok:
        print("FAIL (mismatch)")
        return 1

    print("OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
