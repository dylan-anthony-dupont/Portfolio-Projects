# v43 Reproducibility Pack

This folder contains the **audit harness** for the manuscript build **v43**.

## What this pack certifies (and what it does not)

- It **does** certify a *finite-height front-end* statement and a *low-anchor tail check* (at `m = 10`) in the same
  “certificate + verifier script” format used in v36–v41.
- It **does not** certify the v42 open frontier: **UE-INPUT for the GEO–C4 hinge-circle harmonic endpoint**
  (see Box `UE-INPUT (v43, single active statement)` in `manuscript_v43.tex`).

These certificates are intended to support the manuscript’s bookkeeping and numerical checks; they are **not a proof of RH**.

## Contents

- `v41_tail_check_certificate.json` / `v41_verify_tail_check.py` / `v41_generate_tail_check.py`
- `v41_front_end_certificate.json` / `v41_verify_front_end.py` / `v41_generate_front_end.py`
- `v41_integrity_certificate.json` / `v41_verify_integrity.py`
- `SHA256SUMS.txt`

(Note: the filenames retain the v41 stem for continuity with the existing scripts; v43 changes are manuscript-side and do not
modify the numerical checks in this pack.)

## How to run

From the repository root (or any directory where `v43_repro_pack/` is visible), run:

```bash
python3 v43_repro_pack/v41_verify_integrity.py
python3 v43_repro_pack/v41_verify_tail_check.py
python3 v43_repro_pack/v41_verify_front_end.py
```

## Checksums

`SHA256SUMS.txt` lists SHA-256 hashes for the certificate and script files.
