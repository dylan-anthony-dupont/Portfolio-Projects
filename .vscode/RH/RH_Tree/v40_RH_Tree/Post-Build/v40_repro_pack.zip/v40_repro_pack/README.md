# v40 Reproducibility Pack

This folder contains the **audit harness** for the manuscript build **v40**.

## What this pack certifies (and what it does not)

- It **does** certify a *finite-height front-end* statement and a *low-anchor tail check* (at `m = 10`) in the exact
  “certificate + verifier script” format used in v36–v39.
- It **does not** certify the new **Missing Lever** (ML-Δa) endpoint redesign; that frontier remains **open** in v40
  and is tracked in-text (Box `box:missing-lever-v40`).

## Contents

- `v40_constants_m10.json` — canonical constants + latch flags for the `m=10` tail check.
- `v40_frontend_certificate.json` — front-end verification payload (finite band / procedural cert).
- `v40_generate_frontend_certificate.py` / `v40_verify_frontend_certificate.py`
- `v40_generate_tail_check.py` / `v40_verify_tail_check.py`
- `v40_tail_check_m10.json` — generated tail-check certificate.
- `v40_frontend_verifier_output.txt`, `v40_tail_check_verifier_output_m10.txt` — verifier outputs.
- `SHA256SUMS.txt` — hashes of every file in this folder.

## How to verify

From the directory `v40_repro_pack/`:

```bash
python3 v40_verify_frontend_certificate.py --certificate v40_frontend_certificate.json
python3 v40_verify_tail_check.py --certificate v40_tail_check_m10.json --constants v40_constants_m10.json
```

Both verifiers print `OK` on success and exit non-zero on failure.

