# v37 reproducibility pack (audit harness)

This directory contains small, deterministic scripts and JSON files referenced by `manuscript_v37.tex`.

## What this pack is
- An **audit harness** that evaluates the tail inequality at the low anchor `m=10, α=1`
  for a pinned choice of parameters and constant ledger.
- An explicit **exponent tracker**: the UE exponent `p` is recorded in both the constants file and
  the generated tail-check JSON to prevent silent exponent drift across versions.
- A **fail-closed metadata latch**: every certificate must explicitly declare
  the endpoint/forcing metadata and the budget bookkeeping fields.
  Missing fields are treated as invalid by the verifier.

## v37 schema extensions (new in this pack)
To support the S5′ architecture work in the manuscript, the v37 verifier additionally requires:
- `endpoint_family` (string)
- `forcing_target` (string)
- `budget_tuple` (object with keys `p, theta, q`)
- `growth_model` (object; bookkeeping only)
- `missing_lever_open` (boolean; must be `true` in v37)

These fields are **bookkeeping latches**: they prevent the manuscript from silently pretending the
S5′ “missing lever” is closed.

## What this pack is NOT
- It does **not** certify the analytic constant ledger (`C_up, C1, C2, C_h''`).
- It does **not** prove the tail criterion uniformly in `m`, nor does it claim RH.
- It does **not** compute zeta zeros; the front-end certificate is a logic wrapper around an external result.

## Expected behavior in v37
The low-anchor tail harness still targets the legacy D1 endpoint class (pointwise/sup log-derivative),
for which the UE exponent is `p=1` and the collar/local mechanism makes the local leakage `δ`-inert.
Therefore the tail inequality at `m=10` is typically expected to **fail** for honest constant ledgers.
The harness records this outcome honestly (`"pass": false`) and still verifies reproducibly.

## How to run
From this directory:

```bash
python3 v37_generate_tail_check.py v37_constants_m10.json v37_tail_check_m10.json
python3 v37_verify_tail_check.py --constants v37_constants_m10.json --certificate v37_tail_check_m10.json

python3 v37_verify_frontend_certificate.py --certificate v37_frontend_certificate.json
```

## Files
- `v37_constants_m10.json`: constants + parameters for the low-anchor tail evaluation (includes required metadata latch fields)
- `v37_generate_tail_check.py`: deterministic interval generator (directed-rounding intervals)
- `v37_tail_check_m10.json`: pinned generated tail-check payload (may report `"pass": false`)
- `v37_verify_tail_check.py`: verifier (regen + equality check; fails closed if required metadata missing)
- `v37_tail_check_verifier_output_m10.txt`: verifier console output
- `v37_frontend_certificate.json`: pinned finite-height assumption statement
- `v37_verify_frontend_certificate.py`: logic-only verifier
- `SHA256SUMS.txt`: SHA-256 hashes of the pack files (integrity check)
