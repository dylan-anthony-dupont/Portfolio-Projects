# v41 Reproducibility Pack

This folder contains the **audit harness** for the manuscript build **v41**.

## What this pack certifies (and what it does not)

- It **does** certify a *finite-height front-end* statement and a *low-anchor tail check* (at `m = 10`) in the same
  “certificate + verifier script” format used in v36–v40.
- It **does not** certify the v41 open frontier: the **Geometry Change Requirement** (Box `box:geometry-change-v41`).
  That frontier remains **open** and is tracked in-text.

## Contents

- `v41_constants_m10.json` — canonical constants + latch flags for the `m=10` tail check.
- `v41_frontend_certificate.json` — front-end verification payload (finite band / procedural cert).
- `v41_generate_frontend_certificate.py` / `v41_verify_frontend_certificate.py`
- `v41_generate_tail_check.py` / `v41_verify_tail_check.py`
- `v41_tail_check_m10.json` — generated tail-check certificate.
- `v41_frontend_verifier_output.txt`, `v41_tail_check_verifier_output_m10.txt` — verifier outputs.
- `SHA256SUMS.txt` — hashes of every file in this folder.

## How to verify

From the directory `v41_repro_pack/`:

```bash
python3 v41_verify_frontend_certificate.py --certificate v41_frontend_certificate.json
python3 v41_verify_tail_check.py --certificate v41_tail_check_m10.json --constants v41_constants_m10.json
```

Both verifiers print `OK` on success and exit non-zero on failure.
